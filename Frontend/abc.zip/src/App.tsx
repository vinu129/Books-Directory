import { Flex, Title } from "@mantine/core";
import { Outlet } from "react-router-dom";

function App() {
  return (
    <Flex
      bg={"#eef0ef"}
      direction={"column"}
      style={{ height: "100%", overflow: "hidden" }}
    >
      <Title mt={15} ml={20} order={1}>
        Books Directory App
      </Title>
      <Outlet />
    </Flex>
  );
}

export default App;
