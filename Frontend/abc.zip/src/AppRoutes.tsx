/* eslint-disable @typescript-eslint/no-explicit-any */
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import App from "./App";
import { FileRoutes } from "./core/utility/enums/core.enums";
import Bookdirectory from "./pages/Directory/Bookdirectory";

function AppRoutes() {
  const routes: any = [
    {
      path: "/",
      element: <App />,
      children: [
        {
          path: FileRoutes.DIRECTORY,
          element: <Bookdirectory />,
        },
      ],
    },
  ];
  const router = createBrowserRouter(routes);
  return <RouterProvider router={router}></RouterProvider>;
}

export default AppRoutes;
