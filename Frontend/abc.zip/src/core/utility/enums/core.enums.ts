enum FileRoutes {
  DIRECTORY = "/directory",
}

export { FileRoutes };
