/* eslint-disable @typescript-eslint/no-explicit-any */
import { createApi } from "@reduxjs/toolkit/query/react";
import { axiosBaseQuery } from "../../../../shared/utility/services/axiosBaseQuery.service";
import { API_BASE_URL } from "../../../../environment/environment";
import { IBooks } from "../models/books.model";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const booksApi: any = createApi({
  reducerPath: "booksApi",
  baseQuery: axiosBaseQuery({ baseUrl: API_BASE_URL }),
  tagTypes: ["BooksDirectory"],
  endpoints: (builder) => ({
    // GET Services
    getBooks: builder.query<IBooks[], void>({
      query: () => ({ url: "", method: "GET" }),
      providesTags: ["BooksDirectory"],
      transformResponse: (res: any) => {
        return res.data.books;
      },
    }),
  }),
});

export const { useGetBooksQuery } = booksApi;
