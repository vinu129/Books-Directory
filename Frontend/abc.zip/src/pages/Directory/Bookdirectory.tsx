import {
  Badge,
  Box,
  Flex,
  Group,
  Image,
  SimpleGrid,
  Text,
  Title,
} from "@mantine/core";
import { useEffect, useState } from "react";
import { IBooks } from "./utility/models/books.model";
import { useGetBooksQuery } from "./utility/services/books.service";
import noImageFound from "./../../../public/no-img-found.png";

function Bookdirectory() {
  const { data: BookdirectoryData } = useGetBooksQuery();
  const [booksData, setBooksData] = useState<IBooks[]>();

  useEffect(() => {
    if (BookdirectoryData) {
      setBooksData(BookdirectoryData);
      console.log(booksData);
    }
  }, [BookdirectoryData, booksData]);

  return (
    <SimpleGrid
      style={{ overflow: "auto" }}
      mt={10}
      p={"lg"}
      cols={{ base: 1, sm: 3, lg: 6 }}
      spacing={{ base: 6, sm: "md" }}
      verticalSpacing={{ base: 5, sm: "md" }}
    >
      {booksData &&
        booksData.map((book: IBooks) => (
          <Flex
            direction={"column"}
            align={"center"}
            bg={"white"}
            style={{ border: "1px solid #e7ebe9", borderRadius: "8px" }}
          >
            <Box mt={16} w={150} h={200}>
              <Image
                w={"100%"}
                style={{ borderRadius: "15px" }}
                src={book.thumbnailUrl ? book.thumbnailUrl : noImageFound}
                alt="Norway"
              />
            </Box>
            <Title order={6} ta="center">
              {book.title}
            </Title>
            <Group gap={5} mt={5}>
              <Text fz={12} c="dimmed">
                Author :
              </Text>
              <Text fz={12}>{book.authors[0]}</Text>
            </Group>

            <Text mt={5} fz={12}>
              {book.publishedDate}
            </Text>
            {/* <Flex p={"md"} direction={"column"}>
              <Title order={6}>{book.title}</Title>
              <Text mt={5} fz={12}>
                Author : {book.authors[0]}
              </Text>
              <Text mt={5} fz={12}>
                {book.publishedDate}
              </Text>
              <Badge
                color={book.status === "PUBLISH" ? "green" : "blue"}
                mt={"auto"}
              >
                {book.status}
              </Badge>
            </Flex> */}
          </Flex>
          //   <Card shadow="sm" padding="lg" radius="md" withBorder>
          //     <Card.Section>
          //       <Image src={book.thumbnailUrl} alt="Norway" />
          //     </Card.Section>

          //     <Group justify="space-between" mt="md" mb="xs">
          //       <Text fw={500}>{book.title}</Text>
          //       <Badge color="pink">{book.status}</Badge>
          //     </Group>

          //     <Button color="blue" fullWidth mt="md" radius="md">
          //       Book classic tour now
          //     </Button>
          //   </Card>
        ))}
    </SimpleGrid>
  );
}

export default Bookdirectory;
